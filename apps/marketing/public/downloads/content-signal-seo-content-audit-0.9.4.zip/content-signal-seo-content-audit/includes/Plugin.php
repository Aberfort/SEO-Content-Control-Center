<?php
/**
 * Plugin bootstrap.
 *
 * @package SCCC
 */

declare(strict_types=1);

namespace SCCC\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	public function __construct(
		private readonly ConnectionStore $connectionStore,
		private readonly AdminPage $adminPage,
		private readonly SyncScheduler $syncScheduler,
		private readonly LocalAuditRunner $localAuditRunner,
		private readonly ApiClient $apiClient,
		private readonly SafeOperationEndpoint $safeOperationEndpoint,
		private readonly SystemEventReporter $systemEventReporter,
		private readonly ReviewNudge $reviewNudge
	) {
	}

	public function register(): void {
		add_action( 'admin_menu', array( $this->adminPage, 'registerMenu' ) );
		add_action( 'admin_enqueue_scripts', array( $this->adminPage, 'enqueueAssets' ) );
		add_action( 'admin_post_sccc_exchange_connection', array( $this, 'exchangeConnection' ) );
		add_action( 'admin_post_sccc_disconnect', array( $this, 'disconnect' ) );
		add_action( 'admin_post_sccc_manual_sync', array( $this->syncScheduler, 'handleManualSync' ) );
		add_action( 'admin_post_sccc_run_local_audit', array( $this->localAuditRunner, 'handleRequest' ) );
		add_action( 'admin_post_sccc_save_local_audit_schedule', array( $this->localAuditRunner, 'handleScheduleRequest' ) );
		add_action( 'admin_post_sccc_export_local_audit', array( $this->adminPage, 'exportAuditCsv' ) );
		add_action( 'admin_post_sccc_update_finding_rule', array( $this->adminPage, 'handleFindingRule' ) );
		add_action( 'admin_post_sccc_dismiss_review_nudge', array( $this->reviewNudge, 'handleDismiss' ) );
		add_action( 'sccc_run_manual_sync', array( $this->syncScheduler, 'runSync' ) );
		add_action( 'sccc_run_incremental_sync', array( $this->syncScheduler, 'runSync' ) );
		add_action( LocalAuditRunner::HOOK, array( $this->localAuditRunner, 'run' ) );
		add_action( LocalAuditRunner::RECURRING_HOOK, array( $this->localAuditRunner, 'runScheduled' ) );
		add_action( 'init', array( $this->syncScheduler, 'ensureRecurringSync' ) );
		add_action( 'init', array( $this->localAuditRunner, 'ensureRecurring' ) );
		add_action( 'init', array( $this->systemEventReporter, 'ensureBaseline' ) );
		add_action( 'rest_api_init', array( $this->safeOperationEndpoint, 'registerRoutes' ) );
		add_action( 'wp_dashboard_setup', array( $this->adminPage, 'registerDashboardWidget' ) );
		add_filter( 'site_status_tests', array( $this->adminPage, 'registerSiteHealthTests' ) );
		add_action( 'activated_plugin', array( $this->systemEventReporter, 'onPluginActivated' ), 10, 2 );
		add_action( 'deactivated_plugin', array( $this->systemEventReporter, 'onPluginDeactivated' ), 10, 2 );
		add_action( 'deleted_plugin', array( $this->systemEventReporter, 'onPluginDeleted' ), 10, 2 );
		add_action( 'switch_theme', array( $this->systemEventReporter, 'onThemeSwitched' ), 10, 3 );
		add_action( 'upgrader_process_complete', array( $this->systemEventReporter, 'onUpgraderProcessComplete' ), 10, 2 );
		add_action( '_core_updated_successfully', array( $this->systemEventReporter, 'onCoreUpdated' ) );
		add_action( SystemEventReporter::DELIVER_ACTION, array( $this->systemEventReporter, 'deliver' ) );
	}

	public function exchangeConnection(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to connect this site.', 'content-signal-seo-content-audit' ) );
		}

		check_admin_referer( 'sccc_exchange_connection' );

		$endpoint  = isset( $_POST['sccc_endpoint'] ) ? esc_url_raw( wp_unslash( $_POST['sccc_endpoint'] ) ) : '';
		$challenge = isset( $_POST['sccc_challenge'] ) ? sanitize_text_field( wp_unslash( $_POST['sccc_challenge'] ) ) : '';

		if ( '' === $challenge || '' === $endpoint ) {
			wp_safe_redirect( add_query_arg( 'sccc_error', 'missing_fields', admin_url( 'admin.php?page=sccc&tab=platform' ) ) );
			exit;
		}

		try {
			$connection = $this->apiClient->exchangeConnection( $endpoint, $challenge );
		} catch ( \RuntimeException ) {
			wp_safe_redirect( add_query_arg( 'sccc_error', 'connection_exchange_failed', admin_url( 'admin.php?page=sccc&tab=platform' ) ) );
			exit;
		}

		$this->connectionStore->save(
			$connection['organization_id'],
			$connection['site_id'],
			$connection['token'],
			$connection['endpoint']
		);
		$this->syncScheduler->ensureRecurringSync();

		wp_safe_redirect( add_query_arg( 'sccc_status', 'connected', admin_url( 'admin.php?page=sccc&tab=platform' ) ) );
		exit;
	}

	public function disconnect(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to disconnect this site.', 'content-signal-seo-content-audit' ) );
		}

		check_admin_referer( 'sccc_disconnect' );

		$connection = $this->connectionStore->get();

		if ( null !== $connection ) {
			try {
				$this->apiClient->sendDisconnect( $connection );
			} catch ( \RuntimeException ) {
				wp_safe_redirect( add_query_arg( 'sccc_error', 'disconnect_failed', admin_url( 'admin.php?page=sccc&tab=platform' ) ) );
				exit;
			}
		}

		$this->connectionStore->disconnect();
		$this->syncScheduler->cancelScheduledSyncs();

		wp_safe_redirect( add_query_arg( 'sccc_status', 'disconnected', admin_url( 'admin.php?page=sccc&tab=platform' ) ) );
		exit;
	}
}
